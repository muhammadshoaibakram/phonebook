<?php 
require 'connection.php';

$sql = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('John', 'Doe', 'john211@example.com')";
$query =  $connection->query($sql);
$query2 = 'TRUE';
var_dump($query2); exit;
if ($query === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $connection->error;
}

?>