<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "schools_data";

// Create connection
$connection = new mysqli($username, $servername, $password);

// var_dump($connection); exit;

// Check connection
if ($connection->connect_error) {
  die("Connection failed: " . $connection->connect_error);
}
else
{
  echo "Connected successfully<br>";
}


