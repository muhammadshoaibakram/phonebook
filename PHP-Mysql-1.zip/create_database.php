<?php 
require 'connection.php';
// Create database
$sql = "CREATE DATABASE schools_data";
if ($connection->query($sql) === TRUE) {
  echo "Database created successfully";
} else {
  echo "Error creating database: " . $connection->error;
}
?>