SELECT
	student.`name`,
	student.age,
	student.gender,
	student.percentage,
	states.`name` AS 'States',
	city.`name` AS 'City',
	country.`name` AS 'Country' 
FROM
	student
	INNER JOIN states ON student.state_id = states.id
	INNER JOIN city ON states.city_id = city.id
	INNER JOIN country ON city.country_id = country.id